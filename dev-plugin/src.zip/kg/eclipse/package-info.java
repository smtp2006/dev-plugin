/**
 * JavaDoc.
 */
/**
 * @author whua smtp2006@126.com
 * @version 2014年8月9日下午9:48:27
 */
package kg.eclipse;
